---
tags:
  - Прейскурант
  - Регламент 402
---

# Регламент №402 от 30.06.2025 — Прейскурант

## Быстрый обзор

- **Номер:** 402
- **Дата:** 30.06.2025
- **Тема:** Прейскурант

## Документы (в виде страниц)

- [02 Прил 3-4 Прейскурант Волгоградэнерго 01.07.2025](02-pril-3-4-preyskurant-volgogradenergo-01.07.2025-d7e90d88.md)
- [03 Прил 5 6 Прейскурант Калмэнерго 01.07.2025](03-pril-5-6-preyskurant-kalmenergo-01.07.2025-4342612b.md)
- [04 Прил 7-8 Прейскурант Ростовэнерго 01.07.2025](04-pril-7-8-preyskurant-rostovenergo-01.07.2025-acd5076d.md)
- [Об утверждении прейскуранта с 01.07.2025 2-0 3-0](ob-utverzhdenii-preyskuranta-s-01.07.2025-2-0-3-0-5a04f8ab.md)
- [Пояснительная записка к Приказу](poyasnitelnaya-zapiska-k-prikazu-83398ff7.md)
- [Прил 1-2 Прейскурант Астраханьэнерго 01.07.2025 уточн 8.3.1](pril-1-2-preyskurant-astrahanenergo-01.07.2025-utochn-8.3.1-cc9d5dd0.md)

## Файлы (скачивание)

- [02-pril-3-4-preyskurant-volgogradenergo-01.07.2025-d7e90d88.xlsx](../../assets/402-30062025-preyskurant/02-pril-3-4-preyskurant-volgogradenergo-01.07.2025-d7e90d88.xlsx)
- [03-pril-5-6-preyskurant-kalmenergo-01.07.2025-4342612b.xlsx](../../assets/402-30062025-preyskurant/03-pril-5-6-preyskurant-kalmenergo-01.07.2025-4342612b.xlsx)
- [04-pril-7-8-preyskurant-rostovenergo-01.07.2025-acd5076d.xlsx](../../assets/402-30062025-preyskurant/04-pril-7-8-preyskurant-rostovenergo-01.07.2025-acd5076d.xlsx)
- [ob-utverzhdenii-preyskuranta-s-01.07.2025-2-0-3-0-5a04f8ab.docx](../../assets/402-30062025-preyskurant/ob-utverzhdenii-preyskuranta-s-01.07.2025-2-0-3-0-5a04f8ab.docx)
- [poyasnitelnaya-zapiska-k-prikazu-83398ff7.docx](../../assets/402-30062025-preyskurant/poyasnitelnaya-zapiska-k-prikazu-83398ff7.docx)
- [pril-1-2-preyskurant-astrahanenergo-01.07.2025-utochn-8.3.1-cc9d5dd0.xlsx](../../assets/402-30062025-preyskurant/pril-1-2-preyskurant-astrahanenergo-01.07.2025-utochn-8.3.1-cc9d5dd0.xlsx)
