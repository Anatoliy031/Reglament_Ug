---
tags:
  - Переустройство (переоборудование)
  - Регламент 470
---

# Регламент №470 от 09.08.2024 — Переустройство (переоборудование)

## Быстрый обзор

- **Номер:** 470
- **Дата:** 09.08.2024
- **Тема:** Переустройство (переоборудование)

## Документы (в виде страниц)

- [Договор (002)](dogovor-002-97a1ad8f.md)
- [ПЗ к приказу 02](pz-k-prikazu-02-c7c3c16a.md)
- [Приказ об утверждении типовой формы 5-0](prikaz-ob-utverzhdenii-tipovoy-formy-5-0-5f245690.md)

## Файлы (скачивание)

- [dogovor-002-97a1ad8f.docx](../../assets/470-09082024-pereustroystvo/dogovor-002-97a1ad8f.docx)
- [prikaz-ob-utverzhdenii-tipovoy-formy-5-0-5f245690.docx](../../assets/470-09082024-pereustroystvo/prikaz-ob-utverzhdenii-tipovoy-formy-5-0-5f245690.docx)
- [pz-k-prikazu-02-c7c3c16a.docx](../../assets/470-09082024-pereustroystvo/pz-k-prikazu-02-c7c3c16a.docx)
