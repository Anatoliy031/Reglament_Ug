---
tags:
  - Типовой паспорт услуги
  - Регламент 499
---

# Регламент №499 от 28.08.2023 — Типовой паспорт услуги

## Быстрый обзор

- **Номер:** 499
- **Дата:** 28.08.2023
- **Тема:** Типовой паспорт услуги

## Документы (в виде страниц)

- [Об утверждении типового паспорта 2-0 3-0 4-0](ob-utverzhdenii-tipovogo-pasporta-2-0-3-0-4-0-b9c1d531.md)
- [Пояснительная записка к Приказу](poyasnitelnaya-zapiska-k-prikazu-ad99b6cd.md)
- [Приложение №1 Типовой Паспорт услуги 3-0](prilozhenie-1-tipovoy-pasport-uslugi-3-0-9a351022.md)
- [Приложение №2 Перечень услуг для формирования паспортов 4-0](prilozhenie-2-perechen-uslug-dlya-formirovaniya-pasportov-4-0-306bdb41.md)

### _unpacked_zip

- [prilozhenie-1-tipovoy-pasport-uslugi-3-0-df79ec22](_unpacked_zip/prilozhenie-1-tipovoy-pasport-uslugi-3-0-df79ec22.md)
- [prilozhenie-2-perechen-uslug-dlya-formirovaniya-pasportov-4-0-5ff2c2d0](_unpacked_zip/prilozhenie-2-perechen-uslug-dlya-formirovaniya-pasportov-4-0-5ff2c2d0.md)

## Файлы (скачивание)

- [499-ot-28.08.2023-prilozheniya-1-2-29163deb.zip](../../assets/499-28082023-tipovoy-pasport/499-ot-28.08.2023-prilozheniya-1-2-29163deb.zip)
- [_unpacked_zip/prilozhenie-1-tipovoy-pasport-uslugi-3-0-df79ec22.docx](../../assets/499-28082023-tipovoy-pasport/_unpacked_zip/prilozhenie-1-tipovoy-pasport-uslugi-3-0-df79ec22.docx)
- [_unpacked_zip/prilozhenie-2-perechen-uslug-dlya-formirovaniya-pasportov-4-0-5ff2c2d0.xlsx](../../assets/499-28082023-tipovoy-pasport/_unpacked_zip/prilozhenie-2-perechen-uslug-dlya-formirovaniya-pasportov-4-0-5ff2c2d0.xlsx)
- [_unpacked_zip/prilozheniya-k-pasportu-6a28b309.rar](../../assets/499-28082023-tipovoy-pasport/_unpacked_zip/prilozheniya-k-pasportu-6a28b309.rar)
- [ob-utverzhdenii-tipovogo-pasporta-2-0-3-0-4-0-b9c1d531.docx](../../assets/499-28082023-tipovoy-pasport/ob-utverzhdenii-tipovogo-pasporta-2-0-3-0-4-0-b9c1d531.docx)
- [poyasnitelnaya-zapiska-k-prikazu-ad99b6cd.docx](../../assets/499-28082023-tipovoy-pasport/poyasnitelnaya-zapiska-k-prikazu-ad99b6cd.docx)
- [prilozhenie-1-tipovoy-pasport-uslugi-3-0-9a351022.docx](../../assets/499-28082023-tipovoy-pasport/prilozhenie-1-tipovoy-pasport-uslugi-3-0-9a351022.docx)
- [prilozhenie-2-perechen-uslug-dlya-formirovaniya-pasportov-4-0-306bdb41.xlsx](../../assets/499-28082023-tipovoy-pasport/prilozhenie-2-perechen-uslug-dlya-formirovaniya-pasportov-4-0-306bdb41.xlsx)
- [prilozheniya-k-pasportu-07efc97c.rar](../../assets/499-28082023-tipovoy-pasport/prilozheniya-k-pasportu-07efc97c.rar)
