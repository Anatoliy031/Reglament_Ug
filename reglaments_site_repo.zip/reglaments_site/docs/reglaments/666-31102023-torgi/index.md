---
tags:
  - Торги
  - Регламент 666
---

# Регламент №666 от 31.10.2023 — Торги

## Быстрый обзор

- **Номер:** 666
- **Дата:** 31.10.2023
- **Тема:** Торги

## Документы (в виде страниц)

- [Приложение №1 ПК 10210 087 2023 Порядок участия ПАО Россети Юг в ТЗП в части ДУ 3-0 4-0](prilozhenie-1-pk-10210-087-2023-poryadok-uchastiya-pao-rosseti-yug-v-t-0d78790d.md)
- [Приложение №2 П 10210 568 2023 Положение о работе комиссии филиалов (002) 2-0 3-0](prilozhenie-2-p-10210-568-2023-polozhenie-o-rabote-komissii-filialov-0-827e2666.md)
- [Проект приказа 2-0 3-0 4-0](proekt-prikaza-2-0-3-0-4-0-81776ecb.md)

## Файлы (скачивание)

- [prilozhenie-1-pk-10210-087-2023-poryadok-uchastiya-pao-rosseti-yug-v-t-0d78790d.docx](../../assets/666-31102023-torgi/prilozhenie-1-pk-10210-087-2023-poryadok-uchastiya-pao-rosseti-yug-v-t-0d78790d.docx)
- [prilozhenie-2-p-10210-568-2023-polozhenie-o-rabote-komissii-filialov-0-827e2666.docx](../../assets/666-31102023-torgi/prilozhenie-2-p-10210-568-2023-polozhenie-o-rabote-komissii-filialov-0-827e2666.docx)
- [proekt-prikaza-2-0-3-0-4-0-81776ecb.docx](../../assets/666-31102023-torgi/proekt-prikaza-2-0-3-0-4-0-81776ecb.docx)
