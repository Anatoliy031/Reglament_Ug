---
tags:
  - Эквайринг
  - Регламент 752
---

# Регламент №752 от 07.12.2023 — Эквайринг

## Быстрый обзор

- **Номер:** 752
- **Дата:** 07.12.2023
- **Тема:** Эквайринг

## Документы (в виде страниц)

- [Приложение к приказу 2-0](prilozhenie-k-prikazu-2-0-42338b8d.md)
- [Проект приказа 4-0](proekt-prikaza-4-0-916f3c09.md)

## Файлы (скачивание)

- [prilozhenie-k-prikazu-2-0-42338b8d.docx](../../assets/752-07122023-ekvayring/prilozhenie-k-prikazu-2-0-42338b8d.docx)
- [proekt-prikaza-4-0-916f3c09.docx](../../assets/752-07122023-ekvayring/proekt-prikaza-4-0-916f3c09.docx)
