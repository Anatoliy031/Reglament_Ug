---
tags:
  - Формирование стоимости
  - Регламент 748
---

# Регламент №748 от 06.12.2023 — Формирование стоимости

## Быстрый обзор

- **Номер:** 748
- **Дата:** 06.12.2023
- **Тема:** Формирование стоимости

## Документы (в виде страниц)

- [Проект ПЗ](proekt-pz-fa6e8865.md)
- [Проект приказа об утверждении Порядка 2-0 3-0](proekt-prikaza-ob-utverzhdenii-poryadka-2-0-3-0-daa75bc0.md)

## Файлы (скачивание)

- [.~lock.prilozhenie-pk-3100-091-2023-poryadok-form-stoim-dop-netar-uslug-2-0-3-b3868570.docx#](../../assets/748-06122023-formir-stoimosti/.~lock.prilozhenie-pk-3100-091-2023-poryadok-form-stoim-dop-netar-uslug-2-0-3-b3868570.docx#)
- [prilozhenie-pk-3100-091-2023-poryadok-form-stoim-dop-netar-uslug-2-0-3-b3868570.doc](../../assets/748-06122023-formir-stoimosti/prilozhenie-pk-3100-091-2023-poryadok-form-stoim-dop-netar-uslug-2-0-3-b3868570.doc)
- [prilozheniya-k-poryadku-d48ba388.7z](../../assets/748-06122023-formir-stoimosti/prilozheniya-k-poryadku-d48ba388.7z)
- [proekt-prikaza-ob-utverzhdenii-poryadka-2-0-3-0-daa75bc0.docx](../../assets/748-06122023-formir-stoimosti/proekt-prikaza-ob-utverzhdenii-poryadka-2-0-3-0-daa75bc0.docx)
- [proekt-pz-fa6e8865.docx](../../assets/748-06122023-formir-stoimosti/proekt-pz-fa6e8865.docx)
